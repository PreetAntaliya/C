#include<stdio.h>

void main(){
	int i,j,s;
	
	printf("Patern 15\n\n");
	
	for(i=1;i<=5;i++){
		for(s=4;s>=i;s--){
			printf("  ");
		}
		for(j=i;j>=1;j--){
			printf("%d ",j);
		}
		printf("\n");
	}

}
